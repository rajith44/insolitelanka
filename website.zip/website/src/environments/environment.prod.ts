export const environment = {
  production: true,
  apiUrl: '', // Set to your API base URL in production, e.g. 'https://yoursite.com/api'
  recaptchaSiteKey: '' // Optional: Google reCAPTCHA v2 site key
};
